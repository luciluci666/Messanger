#!D:\Programming\Messanger\server\env\Scripts\python.exe
# EASY-INSTALL-DEV-SCRIPT: 'Tapic==0.0.1','create_db.py'
__requires__ = 'Tapic==0.0.1'
__import__('pkg_resources').require('Tapic==0.0.1')
__file__ = 'D:\\Programming\\Messanger\\server\\scripts\\create_db.py'
with open(__file__) as f:
    exec(compile(f.read(), __file__, 'exec'))
